delete * from users;
