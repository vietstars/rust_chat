delete * from details;
delete * from planets;
