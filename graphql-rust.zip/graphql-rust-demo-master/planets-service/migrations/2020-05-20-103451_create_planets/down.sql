drop table details;
drop table planets;
