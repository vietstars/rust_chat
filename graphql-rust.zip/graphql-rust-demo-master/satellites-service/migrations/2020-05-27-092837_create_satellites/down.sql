drop table satellites;
