delete * from satellites;
